import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, RefreshCw, Settings } from 'lucide-react';
import { type RuntimeConfigDiagnostics } from '../utils/runtimeConfig';

interface BackendConnectionErrorScreenProps {
  diagnostics: RuntimeConfigDiagnostics;
  onRetry: () => void;
  isRetrying?: boolean;
}

export default function BackendConnectionErrorScreen({
  diagnostics,
  onRetry,
  isRetrying = false,
}: BackendConnectionErrorScreenProps) {
  const isConfigError = diagnostics.isBackendCanisterIdMissing;

  return (
    <div className="flex items-center justify-center min-h-[60vh] px-4">
      <Card className="w-full max-w-2xl bg-card/90 backdrop-blur border-border shadow-glow">
        <CardHeader className="text-center space-y-4">
          <div className="w-20 h-20 mx-auto bg-destructive/10 rounded-full flex items-center justify-center border-2 border-destructive/30">
            {isConfigError ? (
              <Settings className="w-10 h-10 text-destructive" aria-hidden="true" />
            ) : (
              <AlertTriangle className="w-10 h-10 text-destructive" aria-hidden="true" />
            )}
          </div>
          <CardTitle className="text-3xl font-display text-foreground">
            {isConfigError ? 'Configuration Error' : 'Connection Error'}
          </CardTitle>
          <CardDescription className="text-base text-muted-foreground">
            {isConfigError
              ? 'The backend canister ID is not configured. The deployment must inject this value before the application can connect to the backend service.'
              : 'Unable to connect to the backend service. Please check your connection and try again.'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex justify-center">
            <Button
              onClick={onRetry}
              disabled={isRetrying}
              variant="default"
              size="lg"
              className="gap-2 min-w-[200px]"
            >
              <RefreshCw className={`w-4 h-4 ${isRetrying ? 'animate-spin' : ''}`} />
              {isRetrying ? 'Retrying...' : 'Retry Connection'}
            </Button>
          </div>

          <details className="p-4 bg-muted/50 rounded-lg border border-border">
            <summary className="cursor-pointer font-semibold text-sm text-foreground mb-3">
              Diagnostics
            </summary>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between items-center py-1">
                <span className="text-muted-foreground">Environment:</span>
                <span className="font-mono text-foreground">{diagnostics.environment}</span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="text-muted-foreground">Authentication Status:</span>
                <span className="font-mono text-foreground">
                  {diagnostics.isAuthenticated ? 'Authenticated' : 'Not Authenticated'}
                </span>
              </div>
              <div className="flex flex-col gap-1 py-1">
                <span className="text-muted-foreground">Backend Canister ID:</span>
                <span className="font-mono text-xs text-foreground break-all bg-background/50 p-2 rounded border border-border">
                  {diagnostics.backendCanisterId || '(not set)'}
                </span>
              </div>
              {isConfigError && (
                <div className="mt-4 p-3 bg-destructive/10 border border-destructive/30 rounded text-xs text-foreground">
                  <p className="font-semibold mb-1">Configuration Required:</p>
                  <p>
                    To fix this issue, the deployment process must set the VITE_BACKEND_CANISTER_ID
                    environment variable to the backend canister's principal ID on the Internet Computer
                    mainnet.
                  </p>
                </div>
              )}
            </div>
          </details>
        </CardContent>
      </Card>
    </div>
  );
}
