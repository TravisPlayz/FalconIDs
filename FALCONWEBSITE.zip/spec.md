# Specification

## Summary
**Goal:** Fix the production admin panel backend connection failure and add clear, actionable diagnostics so admins can reliably access `/admin` without ambiguous “Connection Error” screens.

**Planned changes:**
- Diagnose and fix the `/admin` initialization flow so authenticated admins can load the admin dashboard in production without unhandled promise rejections, runtime exceptions, or requiring manual reloads.
- Add deterministic runtime checks that distinguish configuration issues (e.g., missing/empty backend canister ID) from true connectivity/agent failures, and display a specific configuration error with actionable guidance.
- Add an error UI with a primary recovery action (retry) and a small diagnostics section (e.g., current backend canister ID value if present, and whether the user is authenticated).
- Harden production deployment validation to fail fast when `VITE_BACKEND_CANISTER_ID` is missing/empty, and provide clear guidance on how to obtain/set the IC mainnet canister ID before building/deploying.
- Review and stabilize other authenticated flows that depend on backend actor initialization so they use a proper loading state, support retry without hard refresh where possible, and avoid misleading “access denied” states caused by transient initialization/connectivity issues.

**User-visible outcome:** Authenticated admins can open `/admin` in production and reach the dashboard reliably; if the app is misconfigured (like a missing backend canister ID) they see a clear configuration error with diagnostics and a retry option instead of a generic connection failure.
