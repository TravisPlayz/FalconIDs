import { type ReactNode } from 'react';
import { useActor } from '../hooks/useActor';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useQueryClient } from '@tanstack/react-query';
import { Terminal } from 'lucide-react';
import BackendConnectionErrorScreen from './BackendConnectionErrorScreen';
import { getRuntimeConfigDiagnostics } from '../utils/runtimeConfig';

interface BackendGateProps {
  children: ReactNode;
  loadingMessage?: string;
}

export default function BackendGate({ children, loadingMessage }: BackendGateProps) {
  const { actor, isFetching } = useActor();
  const { identity, isInitializing } = useInternetIdentity();
  const queryClient = useQueryClient();
  const isAuthenticated = !!identity;

  const isLoading = isInitializing || isFetching;

  // Detect if actor initialization has definitively failed
  // Wait until initialization is complete and actor is still null
  const isActorUnavailable = !isInitializing && !isFetching && !actor && isAuthenticated;

  const handleRetry = () => {
    // Invalidate actor query to retry initialization
    queryClient.invalidateQueries({ queryKey: ['actor'] });
    // Also invalidate all dependent queries
    queryClient.invalidateQueries();
  };

  // Show loading state while initializing
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center space-y-4">
          <Terminal className="w-12 h-12 mx-auto text-primary animate-pulse" />
          <div className="text-primary font-mono text-sm tracking-wider">
            {loadingMessage || '[INITIALIZING BACKEND CONNECTION...]'}
          </div>
        </div>
      </div>
    );
  }

  // Show error state only after initialization has definitively failed
  if (isActorUnavailable) {
    const diagnostics = getRuntimeConfigDiagnostics(isAuthenticated);
    return <BackendConnectionErrorScreen diagnostics={diagnostics} onRetry={handleRetry} />;
  }

  return <>{children}</>;
}
