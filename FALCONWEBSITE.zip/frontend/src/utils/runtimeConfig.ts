/**
 * Runtime configuration helper that reads environment values safely
 * and provides diagnostics data for UI rendering.
 */

export interface RuntimeConfigDiagnostics {
  backendCanisterId: string | null;
  isBackendCanisterIdMissing: boolean;
  isAuthenticated: boolean;
  environment: 'development' | 'production';
}

/**
 * Check if the backend canister ID is missing or empty (including whitespace-only)
 */
export function isBackendCanisterIdMissing(): boolean {
  const canisterId = import.meta.env.VITE_BACKEND_CANISTER_ID;
  return !canisterId || canisterId.trim() === '';
}

/**
 * Get the backend canister ID value (or null if missing)
 */
export function getBackendCanisterId(): string | null {
  const canisterId = import.meta.env.VITE_BACKEND_CANISTER_ID;
  if (!canisterId || canisterId.trim() === '') {
    return null;
  }
  return canisterId.trim();
}

/**
 * Get runtime configuration diagnostics for error screens
 */
export function getRuntimeConfigDiagnostics(isAuthenticated: boolean): RuntimeConfigDiagnostics {
  return {
    backendCanisterId: getBackendCanisterId(),
    isBackendCanisterIdMissing: isBackendCanisterIdMissing(),
    isAuthenticated,
    environment: import.meta.env.DEV ? 'development' : 'production',
  };
}
